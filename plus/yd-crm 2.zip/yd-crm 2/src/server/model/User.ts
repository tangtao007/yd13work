export namespace Model {
  export class User {
    email: string;
    name: string;
  }
}
