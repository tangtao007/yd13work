export interface ISocketHandler {
    init();
  }
  