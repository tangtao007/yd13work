const TAGS = {
    IndexService: Symbol.for('IndexService'),
    ApiService: Symbol.for('ApiService')
    // IndexService: 'IndexService'
};

export default TAGS;