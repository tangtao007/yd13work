
// import * as React from 'react';

// export default class home extends React.Component {
//   render() {
//     const { targetKeys, selectedKeys, disabled } = this.state;
//     return (
//       <div>
//         <Transfer
//           dataSource={mockData}
//           titles={['Source', 'Target']}
//           targetKeys={targetKeys}
//           selectedKeys={selectedKeys}
//           onChange={this.handleChange}
//           onSelectChange={this.handleSelectChange}
//           onScroll={this.handleScroll}
//           render={item => item.title}
//           disabled={disabled}
//         />
//         <Switch unCheckedChildren="disabled" checkedChildren="disabled" checked={disabled} onChange={this.handleDisable} style={{ marginTop: 16 }} />
//       </div>
//     );
//   }
// }
