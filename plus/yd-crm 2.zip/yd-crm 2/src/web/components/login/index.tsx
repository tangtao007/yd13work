import * as React from 'react'

function login({ str }) {
  return (
    <p>
        欢迎登陆一灯管理系统
    </p>
  )
}

export default login
