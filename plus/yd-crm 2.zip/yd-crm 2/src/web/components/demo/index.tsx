import "./demo.css";
import * as React from "react";
const { useContext } = React;
import { observer } from "mobx-react-lite";
import TodoStore from "./Store";
import YdStore from "../../models/index";
import TodoList from "./TodoList";
import Footer from "./Footer";
import useDataApi from "../../models/react-hooks-state";
const demo = observer(() => {
  // function demo(props) {
  const store = useContext(TodoStore);
  const ydstore = useContext(YdStore);
  // const data = useDataApi("api/test",{});
  // console.log(data);
  // fetch("api/test").then()
  return (
    <div>
      <h2 className="nav">{ydstore.str}</h2>
      <TodoList todos={store.todos} toggleTodo={store.toggleTodo} />
      <Footer remaining={store.remainingTodos} total={store.todos.length} />
    </div>
  );
});
export default demo;
