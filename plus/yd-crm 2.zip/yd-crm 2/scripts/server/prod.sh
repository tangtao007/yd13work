# gulp 上线环境
cross-env NODE_ENV=production gulp