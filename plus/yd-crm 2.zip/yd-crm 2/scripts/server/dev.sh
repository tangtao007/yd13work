# gulp 开发环境
cross-env NODE_ENV=development ts-node-dev --respawn --transpileOnly src/server/app.ts