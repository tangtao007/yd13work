# 对JavaScript代码进行一个检查校验
cross-env NODE_ENV=lint gulp