const TYPES = {
    SafeRequest: Symbol.for('SafeRequest'),
    SocketHandler:Symbol.for('SocketHandler'),
};

export default TYPES;