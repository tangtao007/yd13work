import * as React from "react";
function login({ str }) {
  return (
      <ul>
        <li>
          <a href="/">首页</a>
        </li>
        <li>
          <a href="/login">登陆页</a>
        </li>
        <li>
          <a href="/demos">混合demos</a>
        </li>
      </ul>
  );
}

export default login;
