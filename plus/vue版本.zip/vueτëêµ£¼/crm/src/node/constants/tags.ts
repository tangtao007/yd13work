// 接口参数的帮助类
const TAGS = {
    ApiService: Symbol.for('ApiService')
}
export default TAGS;