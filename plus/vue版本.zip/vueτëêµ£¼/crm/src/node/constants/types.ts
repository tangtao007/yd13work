// 接口参数的帮助类
const TYPES = {
    SafeRequest: Symbol.for('SafeRequest')
}
export default TYPES;