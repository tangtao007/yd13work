echo "🍔"
cross-env Node_ENV=development gulp