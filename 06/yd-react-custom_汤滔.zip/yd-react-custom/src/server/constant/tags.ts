const TAGS = {
    IndexService:Symbol.for("IndexService")
}
export default TAGS;