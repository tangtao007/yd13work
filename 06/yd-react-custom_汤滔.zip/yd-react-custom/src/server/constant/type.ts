const TYPE = {
    IndexController:Symbol.for("IndexController")
}

export default TYPE;