
export namespace Module{
    export class User{
        email:string;
        name:string;
    }
}