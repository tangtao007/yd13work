import React from 'react'
export default () => <p className="text-success">我是Lazy Comp</p>
